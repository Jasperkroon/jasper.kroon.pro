

// You dirty cheater.
// thanks Zach Holman!

stupid_shit = [
  "is a sea otter",
  "doesn&amp;#39;t ever escape",
  "just wants followers",
  "smells like Donald Trump",
  "refuses simple logos",
  "was replaced by a tiny shell script",
  "loves u",
  "is a donut",
  "disagrees with bud selig",
  "made lots of mistakes",
  "made th netherlands great again",
  "ruined holland too",
  "is part of the problem",
  "failed as a human being",
  "still doesn't understand git",
  "reads a lot of books, once",
  "is a <marquee>&lt;marquee&gt;</marquee> tag",
  "reads every single RFC",
  "doesn't really have a twentsch accent",
  "sunk your battleship"
]
stupid_winner = stupid_shit[Math.floor(Math.random() * stupid_shit.length)];

document.addEventListener("DOMContentLoaded", function(event) {
  document.getElementById("dope").innerHTML = " " + stupid_winner
})
