---
layout: post
title: You're up and running!
---

Next you can update your site name, avatar and other options using the _config.yml file in the root of your repository (shown below).

![_config.yml]({{ site.baseurl }}/images/config.png)

The easiest way to make your first post is to edit this one. Go into /_posts/ and update the Hello World markdown file. For more instructions head over to the [Jekyll Now repository](https://github.com/barryclark/jekyll-now) on GitHub.


from scrum to kanban to scrum again.
https://www.youtube.com/watch?v=7H67V6noueE

https://www.google.nl/search?q=dreyfus+model+of+skill+acquisition&tbm=isch&imgil=c0jDH6FuX9pP4M%253A%253B3Cz81bIojgkd2M%253Bhttps%25253A%25252F%25252Fsetandbma.wordpress.com%25252F2013%25252F02%25252F21%25252Fdreyfus-model%25252F&source=iu&pf=m&fir=c0jDH6FuX9pP4M%253A%252C3Cz81bIojgkd2M%252C_&usg=__ZZyfQo16lC02M7ziL64HozpeaDs%3D&biw=1182&bih=1075&ved=0ahUKEwihoY7Qi53NAhXIcRQKHbIlCREQyjcIOQ&ei=8YBaV-HkGMjjUbLLpIgB#imgrc=s2PBTKNUBVLVKM%3A


https://developer.salesforce.com/blogs/engineering/2015/04/overcommitting-agile-11-practical-solutions-part-2.html


interesting
http://agilescout.com/the-perfect-scrummaster-job-description/


Agile at salesforce:
https://developer.salesforce.com/blogs/engineering/2014/08/agile-methodology-salesforce-inside-look.html


http://www.allaboutagile.com/7-key-principles-of-lean-software-development-2/

brain storm tool
http://www.lorannordgren.com/

27-creativity-innovation-tools-final
http://www.slideshare.net/ramonvullings/27-creativity-innovation-tools-final


http://www.ipmacertificeren.nl/certificeringsniveaus/ipma-pmo/